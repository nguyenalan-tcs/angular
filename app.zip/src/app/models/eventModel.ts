import { Timestamp } from 'rxjs';

interface eventModel {
    name : string
    date : string
    time : string
    duration: string
}

export default eventModel;