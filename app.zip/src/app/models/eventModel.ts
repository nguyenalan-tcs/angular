interface eventModel {
    ID:number
    name : string
    date : string
    time : string
    duration: string
}

export default eventModel;