interface ticketModel {
    eventID: number
    price : number
    amount:number
}

export default ticketModel;