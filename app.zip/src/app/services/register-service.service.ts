import { Injectable } from '@angular/core';
import eventModel from '../../app/models/eventModel';
import { HttpClient } from "@angular/common/http";
import { Router } from "@angular/router"
import { FormControl, FormGroup, ReactiveFormsModule,NgModel } from '@angular/forms';
@Injectable({
  providedIn: 'root',
})
export class RegisterServiceService {
  constructor(private http : HttpClient, private router : Router) {}

  addEvent(event: eventModel) {
    return this.http.post("http://localhost:3000/events", event);
  }
}
