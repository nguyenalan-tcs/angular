import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import 'rxjs';
import {HttpClientModule} from '@angular/common/http';



@Injectable({
  providedIn: 'root'
})
export class AccessDataService {
  baseUrl:string;

  constructor(private http: HttpClient) { 
    this.baseUrl = 'http://dummy.restapiexample.com/api/v1/employees';
  }

  getEmployeesData(): Observable<any>{
    return this.http.get(this.baseUrl);
  }

  getData() : Observable<any>{
    return this.http.get('http://localhost:3000/events');
  }
}
