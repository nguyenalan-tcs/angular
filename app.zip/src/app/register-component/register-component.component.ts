import { Component, OnInit } from '@angular/core';
import eventModel from 'src/app/models/eventModel';
import { RegisterServiceService } from '../services/register-service.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-register-component',
  templateUrl: './register-component.component.html',
  styleUrls: ['./register-component.component.css'],
})
export class RegisterComponentComponent implements OnInit {
  model: eventModel = {name: '', date:'', time: '', duration:'' };

  constructor(
    private registerService: RegisterServiceService,
    private router: Router
  ) {}

  ngOnInit(): void {}

  registerEvent(form) {
    console.log(form);
    this.registerService.addEvent(form.value).subscribe(() => {
      console.log('user added');
      this.model = {
        name: '',
        date: null,
        time: null,
        duration:null,
      };
      this.router.navigate(['completed']);
    });
  }
}
