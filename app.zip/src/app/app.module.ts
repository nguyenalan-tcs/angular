import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule}    from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {AccessDataService} from './services/access-data.service';
/*
import { EmployeeListComponent } from './employee-list/employee-list.component';
import {ColorDirective} from './directives/color.directive';
import { NewemployeeComponent } from './newemployee/newemployee.component';
import { HomeComponent } from './home/home.component';
import { ContactComponent } from './contact/contact.component';
import { EmployeesComponent } from './employees/employees.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { TemplateFormComponent } from './template-form/template-form.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { ConfirmEqualDirective } from './directives/confirm-equal.directive';
import { OrdersComponent } from './orders/orders.component';
import { OrderStatusComponent } from './order-status/order-status.component';
import { OrderDetailsComponent } from './order-details/order-details.component';
import { AddUserComponent } from './add-user/add-user.component';
import { BugTrackerComponent } from './bug-tracker/bug-tracker.component';*/
import { HomeComponent } from './home/home.component';
import {LoginComponentComponent} from './login-component/login-component.component';
import {RegisterComponentComponent} from './register-component/register-component.component';
import { CompletedComponent } from './completed/completed.component';



@NgModule({
  declarations: [
    AppComponent,
    /*EmployeeListComponent,
    ColorDirective,
    NewemployeeComponent,
    ContactComponent,
    EmployeesComponent,
    EmployeeDetailsComponent,
    PageNotFoundComponent,
    TemplateFormComponent,
    ReactiveFormComponent,
    ConfirmEqualDirective,
    OrdersComponent,
    OrderStatusComponent,
    OrderDetailsComponent,
    AddUserComponent,
    BugTrackerComponent,*/
    HomeComponent,
    LoginComponentComponent,
    RegisterComponentComponent,
    CompletedComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [AccessDataService],
  bootstrap: [AppComponent]
})
export class AppModule { }